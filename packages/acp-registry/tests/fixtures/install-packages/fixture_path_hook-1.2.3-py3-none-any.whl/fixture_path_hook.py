import json, os, sys
import fixture_dependency
def main():
    print(json.dumps({'dependency':fixture_dependency.value,'args':sys.argv[1:],'command':sys.argv[0],'launch':os.environ.get('ACP_FIXTURE_LAUNCH')}))
