exports.value = 'dependency-ok';
